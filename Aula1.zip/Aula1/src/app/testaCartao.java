package app;

public class testaCartao {
    static void main(String[] args){
        System.out.println("Teste");
    }
}

