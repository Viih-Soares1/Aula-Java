package app;

public class Funcionario {
    String nome;
    double salario;

    void aumentarSalario(double valor){
        this.salario += valor;
    }
    void diminuirSalario(double valor){
        this.salario -= valor;
    }
    void imprimeDados(){
        System.out.println("Salario: " + this.salario);
    }
    String  consultarDados(){
        return this.nome +"\t "+ this.salario;
    }
}
