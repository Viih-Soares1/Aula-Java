package app;

public class Agencia {
    int numero;
}
