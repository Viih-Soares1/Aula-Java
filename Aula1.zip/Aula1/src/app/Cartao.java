package app;

public class Cartao {

    String nome;
    double numero;
    String venc;
}
