package app;

public class testaFuncionario {
    public static void main(String[] args) {
        //Funcionario fun = new Funcionario();
        //fun.nome = "Vinicius";
        //fun.salario = 1800.0;

        //System.out.println(fun.nome);
        //System.out.println(fun.salario);


        //Funcionario fun2 = new Funcionario();
        //fun2.nome = "Gerundio";
        //fun2.salario = 999;

        //System.out.println(fun2.nome);
       // System.out.println(fun2.salario);

        // TESTANDO MÉTODOS DA CLASSE FUNCIONÁRIO

        Funcionario fun3 = new Funcionario();

        fun3.aumentarSalario(1000);
        fun3.nome = "Espiriquidiberto";
        fun3.imprimeDados();

        System.out.println("Diminuindo o salário...");
        fun3.diminuirSalario(500);
        fun3.imprimeDados();

        String consulta = fun3.consultarDados();
        System.out.println(consulta);

    }
}
