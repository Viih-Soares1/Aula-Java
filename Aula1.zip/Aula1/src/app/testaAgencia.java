package app;

public class testaAgencia {
    public static void main(String[] args) {

        Agencia nmrAgencia = new Agencia();

        nmrAgencia.numero = 1;

        System.out.println("Agência: "+ nmrAgencia.numero);
    }
}
