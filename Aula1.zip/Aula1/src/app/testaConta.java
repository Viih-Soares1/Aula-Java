package app;

import java.util.concurrent.DelayQueue;
import java.util.concurrent.Delayed;

public class testaConta {
    public static void main(String[] args) {
        Conta ct = new Conta();
        ct.numero = 1;
        ct.saldo = 500;
        ct.limite = 1000;



        System.out.println(ct.numero);
        System.out.println(ct.saldo);
        System.out.println(ct.limite);

        System.out.println("Efetuando o saque...");
        ct.sacar(100);
        System.out.println("Saldo Atualizado!");
        System.out.println(ct.consultaValor());

        System.out.println("Efetuando o depósito...");
        ct.depositar(500);

        System.out.println("Saldo Atualizado!");
        System.out.println(ct.consultaValor());
    }


}
