package app;

public class Gerente {
    double salario;
    String nome;

    void aumentaSalario(double taxa){
        this.salario += this.salario * taxa;
    }
    void aumentaSalario(){
       this.aumentaSalario(0.10);
    }

}
