package app;

public class testaGerente {
    public static void main(String[] args) {

        Gerente ge = new Gerente();

        ge.salario = 1000;
        ge.aumentaSalario(0.5);
        System.out.println(ge.salario);
        ge.aumentaSalario(ge.salario);
        System.out.println(ge.salario);
        // testando duas funções com o mesmo nome .   Se não passar parâmetros, ele reconhece o outro métodos
    }
}
