package app;

public class Conta {
    int numero;
    double saldo, limite;

    void depositar(double valor){
        this.saldo += valor;
    }
    void sacar(double valor){
        this.saldo -= valor;
    }
    String consultaValor(){
        return "Saldo: "+ (this.saldo + this.limite);
    }
}
